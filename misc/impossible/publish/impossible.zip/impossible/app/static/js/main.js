$(document).ready(() => {
    $('section').delay(500).fadeIn(500);
});