export FLASK_APP=src
python3 -m pip install -r requirements.txt
python3 run.py
