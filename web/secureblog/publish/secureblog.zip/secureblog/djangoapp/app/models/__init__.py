from app.models.article import Article
from app.models.flag import Flag