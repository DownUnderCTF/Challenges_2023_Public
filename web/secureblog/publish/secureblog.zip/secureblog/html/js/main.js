$(document).ready(() => {
  $('section').delay(1000).fadeIn(1000);
});

particlesJS.load('particles-js', '/js/particles.json', function() {})
