# Login Details

- **username**: `author`
- **password**: `Sup3r secure auth0r pass?`